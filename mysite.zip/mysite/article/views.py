from django.shortcuts import render, get_object_or_404
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from .models import Article
import markdown
import logging
from django.urls import reverse_lazy, reverse
from .forms import ArticlePostForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.models import User 
from django.http import HttpResponse

#logging.config.dictConfig(LOGGING)
logger = logging.getLogger('django.request')

class ArticleListView(ListView):
    model = Article

    # 使用下面的template来返回给浏览器
    template_name = "article/article_index.html" 

    #在template里用“article_list”来引入数据
    context_object_name = "article_list"

    paginate_by = 3



class ArticleDetailView(DetailView):
    model = Article

    template_name = 'article/article_detail.html'

    context_object_name = "article"
    
    # 重写 SingleObjectMixin 类的 get_object方法，根据传进来的pk找到相应的article，加上对markdown的支持。
    def get_object(self):
        article = Article.objects.get(pk = self.kwargs.get("pk"))
        article.body = markdown.markdown(article.body,
        extensions=[
        # 包含 缩写、表格等常用扩展
        'markdown.extensions.extra', 
        # 语法高亮扩展
        'markdown.extensions.codehilite',])
        #logger.error("article content{}".format(article.body))
        return article
    
    # 假如从get请求传进来的是title，urls里写的是path('<slug:title>/', views.ArticleDetailView.as_view(), name='article_detail')， 那么以下两种写法会不报错。    
    #option 1
    # slug_field = "title"
    # slug_url_kwarg = "title"

    # option 2
    # def get_object(self):
    #     return Article.objects.get(title=self.kwargs.get("title"))  # 此步骤self.kwargs是在基类的View的setup函数中赋值的。

class ArticlePostFormView(LoginRequiredMixin, CreateView):
    # 指定model和fields，则不需要在forms里写form，这里利用model生成Formview。
    # model = Article
    # fields = ["title", "author", "body"]

    # 在form里生成form，然后指定form_class和template_name，也可以生成可用的form_view，和上面的方法得到的结果是一样的
    # 但是可以在form里自定义一些内容，改变form显示的样式。
    form_class = ArticlePostForm
    template_name = "article/article_create_form.html"

    # 测试用，在这种情况下，似乎用reverse_lazy也不能解析出网址，会报circular import的错误。
    #logger.error("login:{}".format(reverse_lazy("movies:index")))
    
    # 设置此项才会跳转到登录页面，否则会默认跳转到accounts/login，上面的reverse_lazy办法没法得到地址，只能用硬链接。
    login_url = "/accounts/login/" 
    
    # 调试用，用来看form的具体格式
    # def get_context_data(self, **kwargs):
    #     context = super().get_context_data(**kwargs)
    #     logger.error("context:{}".format(context))
    #     return super().get_context_data(**kwargs)

    # 文章提交不需要添加作者，应当通过获取请求信息自动添加作者，改写form_valid方法添加作者信息给form object。
    # 作者信息从request.session['_auth_user_id']或者self.request.user获得。
    def form_valid(self, form):
        # 先不提交，添加了作者再提交, self.object是Article类的一个实例
        self.object = form.save(commit=False)
        # 获取作者id
        #logger.error("request.user:{}, {}".format(self.request.user, self.request.session['_auth_user_id']))
        self.object.author = User.objects.get(username = self.request.user)
        # 保存到数据库,可以不在中保存，父类的form_valid会执行保存操作
        # self.object.save() 
        # 执行父类的form_valid保存并跳转到成功链接。
        return super().form_valid(form)
    
class ArticleDeleteFormView(LoginRequiredMixin, DeleteView):
    model = Article
    success_url = reverse_lazy("article:article_index") 
    login_url = reverse_lazy("account_login") 

class ArticleUpdateFormView(LoginRequiredMixin, UpdateView):
    form_class = ArticlePostForm
    template_name = "article/article_update_form.html"
    
    # 覆盖get方法以防止用户修改不属于自己的文章，应该有更好的解决办法，暂时用着
    def get(self, request, *args, **kwargs):
        article = Article.objects.get(pk = self.kwargs.get("pk"))
        # 虽然不是自己的文章不会显示编辑按钮，还是要防止通过输入修改文章url的方式来修改其他人的文章
        if self.request.user == article.author:
            return super().get(request, *args, **kwargs)
        else:
            return HttpResponse("您暂时没有权限修改其他人的文章哦")

    def get_object(self):
        article = Article.objects.get(pk = self.kwargs.get("pk"))
        return article
    
