
from django import forms
from .models import Article

class ArticlePostForm(forms.ModelForm):
    class Meta:
        model = Article
        # 写文章只需要输入标题和正文即可，其余的作者，时间之类由后台自动添加
        fields = ("title", "body")
        
        labels = {
            "title": "标题",
            "body": "正文",
        }
        
        widgets = {
            "title": forms.TextInput(attrs={'class':'form-control'}),
            "body": forms.Textarea(attrs={'class':'form-control'}),
        }