from django.urls import path

from . import views

app_name = 'article'
urlpatterns = [
    path('', views.ArticleListView.as_view(), name='article_index'),

    path('<int:pk>/', views.ArticleDetailView.as_view(), name='article_detail'),
    
    path("add/", views.ArticlePostFormView.as_view(), name="article_add"),

    path("update/<int:pk>", views.ArticleUpdateFormView.as_view(), name="article_update"),

    path("delete/<int:pk>", views.ArticleDeleteFormView.as_view(), name="article_delete"),
]